package packets;

public class Packet3ClientDisconnect extends Packet {
	public String clientName;//using a string variable to store the client name

}
