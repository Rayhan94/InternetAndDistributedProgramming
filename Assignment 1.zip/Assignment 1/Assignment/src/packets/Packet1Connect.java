package packets;

public class Packet1Connect extends Packet {//creating a child class of Packet
    public String username;//creating a String username for the person
}
