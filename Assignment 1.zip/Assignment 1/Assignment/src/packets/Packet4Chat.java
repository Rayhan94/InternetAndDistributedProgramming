package packets;

public class Packet4Chat extends Packet {
	public String username, message;

}
