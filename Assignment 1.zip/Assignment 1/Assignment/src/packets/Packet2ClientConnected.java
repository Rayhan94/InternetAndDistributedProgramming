package packets;
//this class sends the client name to the, this class was used to be able to send information
public class Packet2ClientConnected extends Packet {
    public String clientName;//this connects the client name to the server, so it would say John Doe connects to the server
}
