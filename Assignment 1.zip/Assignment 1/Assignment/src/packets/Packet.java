package packets;
//creating a new class called packets
public class Packet {

}
