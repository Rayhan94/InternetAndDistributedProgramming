package packets;

public class Packet3ClientDisconnect extends Packet {
	public String clientName;

}
