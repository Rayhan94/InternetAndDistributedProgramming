package packets;

public class Packet2ClientConnected extends Packet {
    public String clientName;
}
