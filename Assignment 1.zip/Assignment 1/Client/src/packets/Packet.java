package packets;

public class Packet {

}
