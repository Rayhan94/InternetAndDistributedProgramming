package packets;

public class Packet1Connect extends Packet {
    public String username;
}
